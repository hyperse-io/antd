import { isPromise } from '@dimjs/lang';
import { hooks } from '@wove/react';
import { ButtonProps, Dropdown, DropdownProps, Popconfirm, PopconfirmProps } from 'antd';
import { ItemType } from 'antd/lib/menu/hooks/useItems';
import { ReactElement, useMemo, useState } from 'react';
import { ButtonWrapper } from '../button-wrapper';
import { fbaHooks } from '../fba-hooks';
import { fbaUtils } from '../fba-utils';
import './style.less';
import { parentsHasSticky } from './utils';

export interface DropdownMenuItem extends ButtonProps {
  text?: string | ReactElement;
  color?: string;
  onClick?: (event: React.MouseEvent<HTMLElement>) => void | Promise<void>;
  permission?: string;
  needConfirm?: boolean;
  confirmMessage?: string;
  hidden?: boolean;
  popconfirmProps?: Pick<PopconfirmProps, 'placement' | 'okText' | 'cancelText' | 'trigger'>;
}

export interface DropdownMenuWrapperProps extends Omit<DropdownProps, 'menu'> {
  menuList: Array<DropdownMenuItem | null>;
  isFixed?: boolean;
}

export const DropdownMenuWrapper = (props: DropdownMenuWrapperProps) => {
  const { menuList, ...dropdownOtherProps } = props;
  const [menuItems, setMenuItems] = useState<ItemType[]>([]);
  const clsName = hooks.useId(undefined, 'DropdownMenuWrapper');

  const [statusMap, setStatusMap] = useState<Record<string, { open?: boolean; loading?: boolean }>>({});
  const onConfirmtTriggerClick = hooks.useCallbackRef((index, event) => {
    event.stopPropagation();
    setStatusMap({ [index]: { open: true } });
  });

  const onConfirm = hooks.useCallbackRef((item: DropdownMenuItem, index: number, event) => {
    event.stopPropagation();
    const result = item.onClick?.(event);
    if (result && isPromise(result)) {
      statusMap[index] = { loading: true, open: true };
      setStatusMap({ ...statusMap });
      result.finally(() => {
        statusMap[index] = { loading: false, open: false };
        setStatusMap({ ...statusMap });
      });
      return;
    }
    statusMap[index] = { loading: false, open: false };
    setStatusMap({ ...statusMap });
  });

  const onClick = hooks.useCallbackRef((item: DropdownMenuItem, event) => {
    event.stopPropagation();
    return item.onClick?.(event);
  });

  fbaHooks.useEffectCustom(() => {
    const menuItemsNew: ItemType[] = [];
    menuList.filter(Boolean).forEach((item, index) => {
      if (!item) return;
      const {
        text,
        color,
        permission,
        needConfirm,
        confirmMessage,
        hidden,
        type,
        style,
        popconfirmProps,
        ...otherProps
      } = item;
      if (hidden) return;
      if (permission && !fbaUtils.hasPermission(permission)) return;
      const newStyle = color ? { color, ...style } : style;
      const buttonType = type || 'link';
      const nromal = {
        key: index,
        label: (
          <ButtonWrapper
            loadingPosition="center"
            size="small"
            {...otherProps}
            type={buttonType}
            style={newStyle}
            key={index}
            onClick={onClick.bind(null, item)}
          >
            {text}
          </ButtonWrapper>
        ),
      };
      const confirm = {
        key: index,
        label: (
          <Popconfirm
            okText="确定"
            cancelText="取消"
            trigger={['click']}
            destroyTooltipOnHide={true}
            {...popconfirmProps}
            title={confirmMessage}
            onConfirm={onConfirm.bind(null, item, index)}
            onCancel={(event) => {
              event?.stopPropagation();
              setStatusMap({});
            }}
            overlayClassName="dmw-popconfirm"
            arrow={true}
            key={index}
            overlayStyle={{ zIndex: 10 }}
            open={statusMap[index]?.open || false}
            okButtonProps={{
              loading: statusMap[index]?.loading,
            }}
          >
            <ButtonWrapper
              loadingPosition="center"
              size="small"
              danger={color ? false : otherProps.danger}
              {...otherProps}
              onClick={onConfirmtTriggerClick.bind(null, index)}
              type={buttonType}
              style={newStyle}
            >
              {text}
            </ButtonWrapper>
          </Popconfirm>
        ),
      };
      if (needConfirm && !otherProps.disabled) {
        menuItemsNew.push(confirm);
      } else {
        menuItemsNew.push(nromal);
      }
    });
    setMenuItems(menuItemsNew);
  }, [menuList, statusMap]);

  const target = document.querySelector(`.${clsName}`);
  const container = useMemo(() => {
    if (props.isFixed || (target && parentsHasSticky(target))) {
      return undefined;
    }
    return target;
  }, [props.isFixed, target]);

  return (
    <div className={clsName} style={{ position: 'relative' }}>
      <Dropdown
        trigger={dropdownOtherProps?.trigger || ['hover']}
        getPopupContainer={container ? () => target as HTMLElement : undefined}
        arrow={{ pointAtCenter: true }}
        {...dropdownOtherProps}
        overlayStyle={{ zIndex: 9, ...dropdownOtherProps.overlayStyle }}
        menu={{ items: menuItems }}
        onOpenChange={(_open) => {
          if (!_open) {
            setStatusMap({});
          }
        }}
      >
        {props.children}
      </Dropdown>
    </div>
  );
};
